# searcher


## Category
Web
## Description
Мне надоело, что на уроках запрещают искать что-либо в Интернете, пожтому я загрузил этот простой скрипт для обхода.
## Автор
[Art0](https://t.me/vchabk0)
## Level
easy
## Cost
150
## Files
N
## Hosting
Y
## Flag
prune_flag_plug

## Solution
Понимаем, что нужно запрашивать web, и получаем http://web, где лежит флаг.
