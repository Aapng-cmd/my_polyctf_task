# task_name

## Category
Forensics

## Description
well, yeah
hah

## Level
Easy

## Cost
150

## Files
task.zip

## Hosting
N

## Flag
flag_plug

## Hints
hint1|10
hint2|20

## Solution
maybe, heh
<code>This could be</code>
